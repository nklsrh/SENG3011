GROUP 4: FIRE BREATHING RUBBER DUCKIES

EXECUTABLES
-----------

The executables can be found in the following locations:

|| Momentum Strategy Module ||
\SENG3011\executables\MSM_v5.jar

|| ATTP ||
\SENG3011\executables\RubberDuckyTrader.exe - Shortcut

|| Evaluator ||
\SENG3011\GUI\MSM_Trader\MSM_Trader\bin\Release\Evaluator.jar

Note:
MSM_v4.jar is used with the ATTP because it is stable to use with the GUI.
MSM_v5.jar contains additional testing code.
Please use MSM_v5 if you wish to execute the MSM by itself.

============Momentum Strategy Module============

TO RUN:

1. Open cmd/terminal and go to the downloaded JAR's directory
2. Type the following:
java -jar MSM_v5.jar inputFile.csv arguments.txt

Where 
=> java -jar is the function to run a JAR file 
=> MSM_v5.jar is the program module to be run 
=> inputFile.csv is the input SIRCA csv file 
=> arguments.txt is a text file which includes parameters needed for the module. Please use ONLY the format in the 
arguments.txt that has been provided in "\SENG3011\executables\arguments.txt".

3. A log saved to a file MomentumStrategyModule.log
4. A list of approved actions are saved to a new file OrderList.csv. This indicates what equities should be bought or sold.

TO TEST:

1. Open cmd and go to the downloaded JAR's directory
2. Type the following:
java -jar MSM_v5.jar -t -ea inputFile.csv arguments.txt
			OR
java -jar MSM_v5.jar -tv -ea inputFile.csv arguments.txt

The -t flag is used for normal test mode.
The -tv flag is used for verbose test mode.
The -ea flag is *required* to enable assertions in the tests.


============ATTP============

TO RUN:
1. double click the executable in "\SENG3011\executables\RubberDuckyTrader.exe - Shortcut".

If you encounter problems, close the window and try again. If you the problems persist, go to 
"\SENG3011\GUI\MSM_Trader\MSM_Trader\bin\Release" and delete the .cfg file that is there, then
try again.


============Evaluator============

TO RUN:
1. Open cmd/terminal and go to the downloaded JAR's directory
2. Type the following:
java -jar Evaluator.jar OrderList.csv

Where 
=> java -jar is the function to run a JAR file 
=> Evaluator.jar is the program module to be run 
=> OrderList.csv is the output of the MSM
