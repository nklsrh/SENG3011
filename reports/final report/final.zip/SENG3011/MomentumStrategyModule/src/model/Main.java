package model;

public class Main
{	
	/**
	 * The main point of the project. Runs 
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception
	{
		MSMInstance prop = new MSMInstance(args);
		prop.Run();
	}
	
}
